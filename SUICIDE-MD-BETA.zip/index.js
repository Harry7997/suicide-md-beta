const { default: makeWASocket, useMultiFileAuthState } = require('@whiskeysockets/baileys')
const qrcode = require('qrcode-terminal')

async function startBot() {
    const { state, saveCreds } = await useMultiFileAuthState('auth_info')
    const sock = makeWASocket({ auth: state })

    sock.ev.on('connection.update', (update) => {
        const { connection, qr } = update
        if (qr) {
            qrcode.generate(qr, { small: true })
        }
        if (connection === 'open') {
            console.log('✅ Suicide MD Beta is online!')
        }
    })

    sock.ev.on('creds.update', saveCreds)

    sock.ev.on('messages.upsert', async ({ messages }) => {
        const msg = messages[0]
        if (!msg.message) return
        const text = msg.message.conversation || msg.message.extendedTextMessage?.text || ""

        if (text === ".alive") {
            await sock.sendMessage(msg.key.remoteJid, { text: "☠️ Suicide MD Beta is Alive ⚡" })
        }
        if (text === ".ping") {
            await sock.sendMessage(msg.key.remoteJid, { text: "🏓 Pong!" })
        }
    })
}

startBot()