# ☠️ SUICIDE MD BETA ⚡
WhatsApp Bot powered by Baileys.

## 🚀 Deploy on Heroku
1. Fork this repo
2. Connect GitHub repo to Heroku
3. Add Buildpack: `heroku/nodejs`
4. Deploy!

## ⚡ Commands
- .alive → Check if bot is online
- .ping → Pong response
